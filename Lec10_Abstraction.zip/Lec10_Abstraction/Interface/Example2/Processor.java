package Lec10_Abstraction.Interface.Example2;

public class Processor {

    public static void main(String[] args) {
        Circle cirle = new Circle();
        cirle.drawShape();
        cirle.fillColor();
    }
}
