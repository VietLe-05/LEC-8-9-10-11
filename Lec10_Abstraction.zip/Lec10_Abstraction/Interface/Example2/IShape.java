package Lec10_Abstraction.Interface.Example2;

public interface IShape {

    void drawShape();
}
