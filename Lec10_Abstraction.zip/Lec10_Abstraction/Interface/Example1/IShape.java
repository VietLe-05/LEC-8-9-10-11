package Lec10_Abstraction.Interface.Example1;

public interface IShape {

    void drawShape();
}
