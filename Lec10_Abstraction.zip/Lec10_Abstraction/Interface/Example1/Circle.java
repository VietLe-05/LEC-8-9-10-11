package Lec10_Abstraction.Interface.Example1;

public class Circle implements IShape {

    @Override
    public void drawShape() {
        System.out.println("Drawing a circle");
    }
}
