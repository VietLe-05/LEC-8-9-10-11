package Lec10_Abstraction.Interface.MultiInheritance;

public interface IColor {

    void fillColor();
}
