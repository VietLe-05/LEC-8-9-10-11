package Lec10_Abstraction.Interface.MultiInheritance;

public interface IShape {

    void drawShape();
}
