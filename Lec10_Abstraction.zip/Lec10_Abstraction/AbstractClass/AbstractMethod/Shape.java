package Lec10_Abstraction.AbstractClass.AbstractMethod;

public abstract class Shape {

    public abstract double calculateArea();
}
