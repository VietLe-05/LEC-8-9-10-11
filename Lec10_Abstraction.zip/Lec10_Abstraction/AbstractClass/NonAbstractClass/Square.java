package Lec10_Abstraction.AbstractClass.NonAbstractClass;

public class Square extends Shape {
}
