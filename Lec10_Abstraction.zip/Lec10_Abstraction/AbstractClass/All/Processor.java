package Lec10_Abstraction.AbstractClass.All;

public class Processor {
    public static void main(String[] args) {
        Dog dog = new Dog("Lulu");
        dog.displayName();
        dog.makeSound();
    }
}
